	project "BussIK"
		
	kind "StaticLib"

	includedirs {
		"."
	}
	files {
		"*.cpp",
		"*.h",
	}
